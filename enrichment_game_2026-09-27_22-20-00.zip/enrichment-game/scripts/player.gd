extends CharacterBody2D
@onready var animated_sprite_2d: AnimatedSprite2D = $AnimatedSprite2D
@onready var jumpsound: AudioStreamPlayer2D = $jumpsound
@onready var deathsound: AudioStreamPlayer2D = $deathsound
@onready var timerlabel: Label = $timer/timerlabel


const SPEED = 350.0
const JUMP_VELOCITY = -850
var alive = true

func _physics_process(delta: float) -> void:
	if !alive:
		return
	
	#add animation
	if velocity.x>1 or velocity.x<-1:
		animated_sprite_2d.animation = "running"
	else:
		animated_sprite_2d.animation = "idle"
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta
		animated_sprite_2d.animation = "jumping"

	# Handle jump.
	if Input.is_action_pressed("jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY
		jumpsound.play()

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var direction := Input.get_axis("left", "right")
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	move_and_slide()
	
	if direction== 1.0:
		animated_sprite_2d.flip_h = false
	if direction== -1.0:
		animated_sprite_2d.flip_h = true
		
		
	if position.y>1500:
		die()
	
func die() -> void:
	deathsound.play()
	print("player killed")
	animated_sprite_2d.animation = "dying"
	alive = false
