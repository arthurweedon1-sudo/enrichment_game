extends Node2D
var score: int = 0
@onready var score_label: Label = $HUD/scorePanel/ScoreLabel
@onready var timerlabel: Label = $HUD/timer/timerlabel
@onready var player: Node2D = $levelroot/player


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.
	_setup_level()

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass
	
func _setup_level() -> void:
	timer()
	#connect collectables
	var collectables = $levelroot.get_node_or_null("collectables")
	if collectables:
		for collectable in collectables.get_children():
			collectable.collected.connect(increase_score)
	#connect enemies
	var enemies = $levelroot.get_node_or_null("enemies")
	if enemies:
		for enemy in enemies.get_children():
			enemy.player_died.connect(_on_player_died)

func timer():
	for mins in range(5):
		for secs in range(60):
			timerlabel.text = str(mins) + " : " + str(secs)
			await get_tree().create_timer(1).timeout
	player.die()

			
#-------------------
# SIGNAL HANDLERS
#-------------------
func _on_player_died(body):
	body.die()

#-------------------
# SCORE
#-------------------
func increase_score() -> void:
	score+=1
	score_label.text = "SCORE: %s" % score
